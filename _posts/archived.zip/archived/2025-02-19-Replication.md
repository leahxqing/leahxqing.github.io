---
title: 'Replication'
date: 2025-02-19
permalink: /posts/replication/
tags:
  - Reading
---
This page contains literature replication code written by me.

## Table

|                        Article & Code                        | Software Language | Update Date |
| :----------------------------------------------------------: | :---------------: | ----------- |
| Berry et al. (1995) - Automobile Prices in Market Equilibrium |     `Matlab`      |             |
